a) PART: stm32l053r8t6
b) PROGRAMMING INTERFACE: SWD
c) FIRMWARE HEX: attached
d) BOARD IMAGE:attached

==========TESTS========
following TESTS need to done on atleast one board in a batch to confirm programming and assembly are okay

1) Test if leds glow
2) Test if USB is detected as a COM port (or /dev/ttyACM device linux)
3) Test if buzzer beeps on touching the 6 touch sensitive tracks on the top side of the PCB